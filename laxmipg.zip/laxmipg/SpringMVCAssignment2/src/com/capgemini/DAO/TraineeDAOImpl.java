package com.capgemini.DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.entities.Trainee;
import com.capgemini.exception.TraineeException;

@Repository("traineeDao")
public class TraineeDAOImpl implements ITraineeDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	
	
	
	
	@Override
	public int addTrainee(Trainee trainee) throws TraineeException {
		
		int traineeId = 0;
		try
		{
			entityManager.persist(trainee);
			traineeId=trainee.getTraineeId();
					
			
		}
		catch(Exception e)
		{
			throw new TraineeException(e.getMessage());
		}
		return traineeId;
	}

	@Override
	public Trainee getTrainee(int tid) throws TraineeException 
	{
		Trainee trainee = null;
		try
		{
			trainee = entityManager.find(Trainee.class, tid);
			
			
		}
		catch(Exception e)
		{
			
		}
		return trainee;
	}

	@Override
	public void UpdateTrainee(Trainee trainee) throws TraineeException {
		
		try
		{
			entityManager.merge(trainee);
			entityManager.flush();
		}
		catch(Exception e)
		{
			throw new TraineeException(e.getMessage());
		}
		
	}

	@Override
	public List<Trainee> getAllTrainee() throws TraineeException {
		
		List<Trainee> traineeList = null ;
		try
		{
			TypedQuery<Trainee> tquery = entityManager.createQuery("select t from Trainee t", Trainee.class) ;
			traineeList = tquery.getResultList();
		}
		catch(Exception e)
		{
			throw new TraineeException(e.getMessage());
		}
		if(traineeList == null || traineeList.isEmpty())
		{
			throw new TraineeException("No Tainees Available");
		}
		return traineeList;
	}

	@Override
	public void removeTrainee(int tid) throws TraineeException 
	{
		try
		{
			 entityManager.remove(tid);
			
			
		}
		catch(Exception e)
		{
			
		}
	}

}
