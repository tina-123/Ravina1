package com.capgemini.gym.service;

import java.util.List;

import com.capgemini.gym.entities.Customer;
import com.capgemini.gym.exception.GymBookingException;

public interface IBookingService
{
	public int addCustomer(Customer customer) throws GymBookingException;
	public Customer getCustomer(int id)throws GymBookingException;
	public List<Customer> getAllCustomer() throws GymBookingException ;
	public void updateCustomer(Customer customer) throws GymBookingException;


}
