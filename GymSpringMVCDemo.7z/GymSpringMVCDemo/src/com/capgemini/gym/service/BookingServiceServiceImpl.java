package com.capgemini.gym.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.gym.dao.IBookingDao;
import com.capgemini.gym.entities.Customer;
import com.capgemini.gym.exception.GymBookingException;

@Service // service bean 
@Transactional
public class BookingServiceServiceImpl implements IBookingService 
{
	@Autowired //do autowiring for the dao inetrface 
	private IBookingDao bookingDao;

	public BookingServiceServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookingServiceServiceImpl(IBookingDao bookingDao) {
		super();
		this.bookingDao = bookingDao;
	}

	public IBookingDao getBookingDao() {
		return bookingDao;
	}

	public void setBookingDao(IBookingDao bookingDao) {
		this.bookingDao = bookingDao;
	}
	//===================================================//

	@Override
	public int addCustomer(Customer customer) throws GymBookingException 
	{
		
		return bookingDao.addCustomer(customer);
	}

	@Override
	public Customer getCustomer(int id) throws GymBookingException
	{
		
		return bookingDao.getCustomer(id);
	}

	@Override
	public List<Customer> getAllCustomer() throws GymBookingException {
		return bookingDao.getAllCustomer();
	}

	@Override
	public void updateCustomer(Customer customer) throws GymBookingException 
	{
		bookingDao.updateCustomer(customer);
	}

}
