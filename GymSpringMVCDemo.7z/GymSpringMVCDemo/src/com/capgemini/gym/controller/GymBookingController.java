package com.capgemini.gym.controller;


import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.gym.entities.Customer;
import com.capgemini.gym.service.IBookingService;

@Controller 
public class GymBookingController 
{
@Autowired
private IBookingService bookingService;

public GymBookingController() {
	super();
	// TODO Auto-generated constructor stub
}

public GymBookingController(IBookingService bookingService) {
	super();
	this.bookingService = bookingService;
}

public IBookingService getBookingService() {
	return bookingService;
}

public void setBookingService(IBookingService bookingService) {
	this.bookingService = bookingService;
}



//==============================================//
@RequestMapping("addCustomer")
public String getAddCustomerPage(Model model)
{
	List<String>gymNames=new ArrayList<>();
	gymNames.add("Gold GYM");
	gymNames.add("Tawalkars Gym");
	gymNames.add("silver Gym");
	gymNames.add("Body Fitness");
	
	List<String>timings=new ArrayList<>();
	
	timings.add("Morning");
	timings.add("AfterNoon");
	timings.add("Evening");
	timings.add("Night");
	
	model.addAttribute("gymNames",gymNames);//For Dropdown
	model.addAttribute("timings",timings);// CheckBoxes
	model.addAttribute("customer",new Customer());
	
	
	return "AddCutomerPage";
}
@RequestMapping(value="processAddCustomerForm",method=RequestMethod.POST)
public String processAddCustomerForm(
		@ModelAttribute("customer")@Valid Customer customer,
		BindingResult result,Model model)
		{
	if(result.hasErrors())
	{
		List<String>gymNames=new ArrayList<>();
		gymNames.add("Gold GYM");
		gymNames.add("Tawalkars Gym");
		gymNames.add("silver Gym");
		gymNames.add("Body Fitness");
		
		List<String>timings=new ArrayList<>();
		
		timings.add("Morning");
		timings.add("AfterNoon");
		timings.add("Evening");
		timings.add("Night");
		
		model.addAttribute("gymNames",gymNames);//For Dropdown
		model.addAttribute("timings",timings);// CheckBoxes
		model.addAttribute("customer",customer);
		
		return "AddCutomerPage";
	
		}
	int customerid=-1;
	try
	{
		customerid=bookingService.addCustomer(customer);
		
	} 
	catch (Exception e)
	{
     e.printStackTrace();
     model.addAttribute("errMsg","Something went wrong while adding customer reason"+e.getMessage());
     return"ErrorPage";
}
	model.addAttribute("successMsg","Customer added successfully with id"+customerid);
	return "SuccessPage";

}

@RequestMapping("viewCustomer.do")
public String getViewCustomerPage()
{
	return "ViewCustomerpage";
}

@RequestMapping(value="processviewCustomerDetailsForm",method=RequestMethod.POST)
public String processViewCustomerForm(@RequestParam("customerId")int id,Model model)
{
	Customer customer=null;
	try 
	{
		customer=bookingService.getCustomer(id);
		
	}
	catch (Exception e) 
	{
		e.printStackTrace();
	     model.addAttribute("errMsg","Something went wrong while Retrieving customer details reason"+e.getMessage());
	     return"ErrorPage";
	}
	model.addAttribute("customer", customer);
	return "ViewCustomerpage";
}
@RequestMapping(value="viewAllCustomer")
 public String getAllCustomersPage(Model model)
 {
	
	List <Customer> customers=null;
	try 
	{
		customers=bookingService.getAllCustomer();
		model.addAttribute("customers",customers);
	} 
	catch (Exception e) 
	{
		model.addAttribute("errMsg", "Could not Display Complaint Reason: "+e.getMessage());
		return "ErrorPage";			
		}
	
    
return "ViewAllCustomers";
}
@RequestMapping("getupdatepage")
public String getUpdatePage(@RequestParam("cid") int id,Model model)
{
	List<String>gymNames=new ArrayList<>();
	gymNames.add("Gold GYM");
	gymNames.add("Tawalkars Gym");
	gymNames.add("silver Gym");
	gymNames.add("Body Fitness");
	
	List<String>timings=new ArrayList<>();
	
	timings.add("Morning");
	timings.add("AfterNoon");
	timings.add("Evening");
	timings.add("Night");
	
	Customer customer=null;
	try 
	{
		customer=bookingService.getCustomer(id);
		
	} 
	catch (Exception e) 
	{
		model.addAttribute("errMsg","Could not retriivr product id Reason: "+e.getMessage());
		return "ErrorPage";	
		}
	
	model.addAttribute("gymNames",gymNames);//For Dropdown
	model.addAttribute("timings",timings);// CheckBoxes
	model.addAttribute("customer",new Customer());
	
	return "UpdatePage";
	
}

}


