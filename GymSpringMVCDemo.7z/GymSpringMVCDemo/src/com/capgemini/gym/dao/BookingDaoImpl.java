package com.capgemini.gym.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;



import com.capgemini.gym.entities.Customer;
import com.capgemini.gym.exception.GymBookingException;

@Repository
public class BookingDaoImpl implements IBookingDao
{
	@PersistenceContext
	private EntityManager entityManager;

	
	public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}


	public BookingDaoImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}


	public BookingDaoImpl()
	{
		super();
	}
	/*=====================================================*/


	@Override
	public int addCustomer(Customer customer) throws GymBookingException 
	{
		int bookingId=-1;
		
		try
		{
			entityManager.persist(customer);
			bookingId=customer.getId();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new GymBookingException(e.getMessage());
		}
		return bookingId;
	}


	@Override
	public Customer getCustomer(int id) throws GymBookingException
	{
   Customer customer=null;
   try
   {
	   customer=entityManager.find(Customer.class,id);
	
  } 
   catch (Exception e)
   {
     e.printStackTrace();
     throw new GymBookingException();
}
   if(customer==null)
   {
	   throw new GymBookingException();
	   
   }
return customer;
	}


	@Override
	public List<Customer> getAllCustomer() throws GymBookingException 
	{
	List<Customer> customers=null;
	try 
	{
		TypedQuery<Customer> query = entityManager.createQuery("select c from Customer c",Customer.class);
		customers = query.getResultList();		
	}
	catch (Exception e)
	{
		throw new GymBookingException(e.getMessage());

	}
	if(customers == null || customers.isEmpty())
	{
		throw new GymBookingException("No Customers to display");
	}
	return customers;
	}


	@Override
	public void updateCustomer(Customer customer) throws GymBookingException 
	{
		
		try
		{
			entityManager.merge(customer) ;
			entityManager.flush();
			
		}
		catch (Exception e) 
		{
			throw new GymBookingException(e.getMessage());

		}
		
	}
	
	
	

}
