create sequence custidseq start with 1000;
drop sequence custidseq;
select * from CustomerDetails;