package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;









import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.BindingResultUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.Dao.IComplaintDaoImpl;
import com.capgemini.entities.Complaints;
import com.capgemini.service.IComplaintService;

@Controller
public class ComplainController 
{
	@Autowired
IComplaintService complaintService;

	public ComplainController()
	{
	}

	public ComplainController(IComplaintService complaintService) {
		super();
		this.complaintService = complaintService;
	}

	public IComplaintService getComplaintService() {
		return complaintService;
	}

	public void setComplaintService(IComplaintService complaintService) {
		this.complaintService = complaintService;
	}
	@RequestMapping("home")
	public String getHomePage()
	{
		return "HomePage";
	}
	
	@RequestMapping("addComplaint")
	public String getAddComplaintPage(Model model)
	{
		List<String>categories=new ArrayList<>();
		categories.add("Internet Issue");
		categories.add("Printer Issue");
        categories.add("Cleanliness Issue");
        
        model.addAttribute("complaints",new Complaints());
        model.addAttribute("categories",categories);
        
        return "AddComplaintpage"; 
        
       

		
	}
	@RequestMapping("ProcessAddComplaintForm")
public ModelAndView processAddComplaint(@ModelAttribute("complaints")@Valid Complaints complaints
		,BindingResult result,Model model)
		{
		if(result.hasErrors())
		{
			List<String>categories=new ArrayList<>();
			categories.add("Internet Issue");
			categories.add("Printer Issue");
	        categories.add("Cleanliness Issue");
	        
	        model.addAttribute("complaints",new Complaints());

	       	
		
		return new ModelAndView("AddComplaintpage");
		}
		int cid=-1;
		try
		{
			cid=complaintService.addComplaint(complaints);
			
			model.addAttribute("msg","Complaint added Successfully with complaint id "+cid);
		
		return new ModelAndView("SuccessPage");
		}
			
		 catch (Exception e) 
		{
			 model.addAttribute("errMsg","Could Not add Complaint"+e.getMessage());
			 return new ModelAndView("ErrorPage");
		}
			
		}
}

