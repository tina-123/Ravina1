package com.capgemini.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.Dao.ComplaintDaoImpl;
import com.capgemini.Dao.IComplaintDaoImpl;
import com.capgemini.entities.Complaints;
import com.capgemini.exception.ComplaintException;

@Transactional
@Service("complaintService")
public class ComplaintServiceImpl implements IComplaintService
{
	@Autowired
	IComplaintDaoImpl complaintDao;
	
	
	

	public ComplaintServiceImpl()
	{
		complaintDao= new ComplaintDaoImpl();
		
	}
	
	

	public ComplaintServiceImpl(IComplaintDaoImpl complaintDao)
	{
		super();
		this.complaintDao = complaintDao;
	}



	public IComplaintDaoImpl getComplaintDao() {
		return complaintDao;
	}



	public void setComplaintDao(IComplaintDaoImpl complaintDao) {
		this.complaintDao = complaintDao;
	}



	@Override
	public int addComplaint(Complaints complaints) throws ComplaintException {
		
		return complaintDao.addComplaint(complaints);
	}

	@Override
	public Complaints getComplaint(int cid) throws ComplaintException {
		
		return complaintDao.getComplaint(cid);
	}

	@Override
	public List<Complaints> getAllComplaint() throws ComplaintException {
		
		return complaintDao.getAllComplaint();
	}

	@Override
	public void reomveComplaint(int cid) throws ComplaintException 
	{
		complaintDao.reomveComplaint(cid);
	}

}
