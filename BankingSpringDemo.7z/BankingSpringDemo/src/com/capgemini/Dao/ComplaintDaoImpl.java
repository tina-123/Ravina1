package com.capgemini.Dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.capgemini.entities.Complaints;
import com.capgemini.exception.ComplaintException;

@Repository("complaintDao")
public class ComplaintDaoImpl implements IComplaintDaoImpl
{
	@PersistenceContext
private  EntityManager entityManager;






	public ComplaintDaoImpl() 
	{
	
}

	@Override
	public int addComplaint(Complaints complaints) throws ComplaintException 
	{
		int cid=0;
		try
		{
			entityManager.persist(complaints);
			cid=complaints.getCid();
			
		}
		catch(Exception e)
		{
			throw new ComplaintException(e.getMessage());
		}
		return cid ;
	}

	@Override
	public Complaints getComplaint(int cid) throws ComplaintException 
	{
		Complaints complain=null;
		try 
		{
			complain=entityManager.find(Complaints.class, cid);
			
		} catch (Exception e) 
		{
			throw new ComplaintException(e.getMessage());
		}
		return complain;
	}

	@Override
	public List<Complaints> getAllComplaint() throws ComplaintException 
	{
		List<Complaints> complaint=new ArrayList<Complaints>();
		try 
		{
			complaint=entityManager.createQuery("from Complaint").getResultList();
			
		} catch (Exception e)
		{
			throw new ComplaintException(e.getMessage());
		}
		return complaint;
	}

	@Override
	public void reomveComplaint(int cid) throws ComplaintException
	{

	}

}
