package com.capgemini.Dao;

import java.util.List;

import com.capgemini.entities.Complaints;
import com.capgemini.exception.ComplaintException;

public interface IComplaintDaoImpl
{
	public int addComplaint(Complaints complaints) throws ComplaintException;
	public Complaints getComplaint(int cid) throws ComplaintException;
	public List<Complaints> getAllComplaint() throws ComplaintException;
	public void reomveComplaint(int cid) throws ComplaintException;

}
