package com.capgemini.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Complaints")
public class Complaints
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseqgen")
	@SequenceGenerator(name="myseqgen",sequenceName="seqComplaint",initialValue=1000)
	@Column(name="id")
private int cid;
	
	@NotEmpty(message="Complaint name cannot be Blank")
@Column(name="cname",nullable=false)
private String cname;
	
@NotEmpty(message="Complaint Title Cannot be Blank")
@Column(name="cTitle",nullable=false)
private String cTitle;

@NotEmpty(message="Complaint Category cannot be blank")
@Column(name="category",nullable=false)
private String category;

public Complaints()
{
	super();
}
public Complaints(int cid, String cname, String cTitle, String category) {
	super();
	this.cid = cid;
	this.cname = cname;
	this.cTitle = cTitle;
	this.category = category;
}
@Override
public String toString() {
	return "Complaints [cid=" + cid + ", cname=" + cname + ", cTitle=" + cTitle
			+ ", category=" + category + "]";
}
public Complaints(String cname, String cTitle, String category) {
	super();
	this.cname = cname;
	this.cTitle = cTitle;
	this.category = category;
}
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getcTitle() {
	return cTitle;
}
public void setcTitle(String cTitle) {
	this.cTitle = cTitle;
}
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}

}
